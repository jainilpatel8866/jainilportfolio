import { useRef, useState } from "react";
import { motion, useInView } from "motion/react";
import { Linkedin, Mail, Github, ArrowUp, Heart, MapPin, Phone, Sparkles } from "lucide-react";

const navLinks = [
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Experience", href: "#experience" },
  { label: "Projects", href: "#projects" },
  { label: "Certifications", href: "#certifications" },
  { label: "Contact", href: "#contact" },
];

const socialLinks = [
  { icon: Github, href: "https://github.com", label: "GitHub", color: "#E8E8ED" },
  { icon: Linkedin, href: "https://linkedin.com/in/kailajainil", label: "LinkedIn", color: "#0A66C2" },
  { icon: Mail, href: "mailto:jainilkaila@gmail.com", label: "Email", color: "#4F9CFF" },
];

export function Footer() {
  const nameRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(nameRef, { once: true });
  const [hoveredSocial, setHoveredSocial] = useState<number | null>(null);

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  const nameText = "KAILA JAINIL";

  return (
    <footer className="relative overflow-hidden">
      {/* Gradient mesh background */}
      <div className="absolute inset-0">
        <motion.div
          className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-[#4F9CFF]/[0.07] rounded-full blur-[180px]"
          animate={{ x: [0, 40, 0], y: [0, -30, 0] }}
          transition={{ repeat: Infinity, duration: 12, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-[#8B5CF6]/[0.07] rounded-full blur-[160px]"
          animate={{ x: [0, -30, 0], y: [0, 20, 0] }}
          transition={{ repeat: Infinity, duration: 10, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute top-1/3 right-1/3 w-[300px] h-[300px] bg-[#EC4899]/[0.04] rounded-full blur-[120px]"
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ repeat: Infinity, duration: 8, ease: "easeInOut" }}
        />
      </div>

      {/* Top wave separator */}
      <div className="relative">
        <svg className="w-full h-20 md:h-28" viewBox="0 0 1440 100" preserveAspectRatio="none">
          <defs>
            <linearGradient id="footerWaveGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#4F9CFF" stopOpacity="0.15" />
              <stop offset="50%" stopColor="#8B5CF6" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#EC4899" stopOpacity="0.15" />
            </linearGradient>
          </defs>
          <motion.path
            d="M0,60 C360,90 720,10 1080,50 C1260,70 1380,40 1440,60 L1440,100 L0,100 Z"
            fill="url(#footerWaveGrad)"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.5 }}
          />
          <motion.path
            d="M0,70 C240,40 480,90 720,60 C960,30 1200,80 1440,55 L1440,100 L0,100 Z"
            fill="rgba(79,156,255,0.05)"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.5, delay: 0.3 }}
          />
        </svg>
      </div>

      <div className="relative z-10 pt-8 pb-8">
        <div className="max-w-7xl mx-auto px-6">

          {/* Giant name section */}
          <div ref={nameRef} className="text-center mb-16 relative">
            {/* Animated horizontal lines */}
            <motion.div
              className="absolute top-1/2 left-0 right-0 -translate-y-1/2 flex items-center justify-center pointer-events-none"
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 0.15 } : {}}
              transition={{ delay: 0.6, duration: 1 }}
            >
              <div className="flex-1 h-px bg-gradient-to-r from-transparent via-[#4F9CFF]/50 to-[#8B5CF6]/50" />
              <div className="w-3 h-3 rounded-full border border-[#4F9CFF]/40 mx-4" />
              <div className="flex-1 h-px bg-gradient-to-l from-transparent via-[#8B5CF6]/50 to-[#EC4899]/50" />
            </motion.div>

            {/* Name */}
            <div className="overflow-hidden py-4">
              <div className="flex flex-wrap justify-center gap-x-[0.02em]">
                {nameText.split("").map((char, index) => (
                  <div key={`name-${index}`} className="overflow-hidden">
                    <motion.span
                      className={`inline-block select-none ${char === " " ? "w-[0.3em]" : ""}`}
                      style={{
                        fontSize: "clamp(2.5rem, 10vw, 8rem)",
                        fontWeight: 900,
                        lineHeight: 1,
                        letterSpacing: "-0.02em",
                        fontFamily: "'Inter', 'Poppins', sans-serif",
                        background: "linear-gradient(135deg, #ffffff 0%, #4F9CFF 35%, #8B5CF6 65%, #EC4899 100%)",
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                        backgroundClip: "text",
                        backgroundSize: "200% 200%",
                      }}
                      initial={{ y: "120%", opacity: 0, rotateX: -45 }}
                      animate={isInView ? { y: "0%", opacity: 1, rotateX: 0 } : {}}
                      transition={{
                        duration: 0.9,
                        delay: index * 0.04,
                        ease: [0.22, 1, 0.36, 1],
                      }}
                    >
                      {char === " " ? "\u00A0" : char}
                    </motion.span>
                  </div>
                ))}
              </div>
            </div>

            {/* Shimmer overlay on text */}
            <motion.div
              className="absolute inset-0 pointer-events-none"
              style={{
                background: "linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.1) 50%, transparent 100%)",
                backgroundSize: "200% 100%",
              }}
              initial={{ backgroundPosition: "-200% 0" }}
              animate={isInView ? { backgroundPosition: ["200% 0", "-200% 0"] } : {}}
              transition={{ duration: 3, delay: 1.2, repeat: Infinity, repeatDelay: 4, ease: "easeInOut" }}
            />

            {/* Subtitle */}
            <motion.div
              className="flex items-center justify-center gap-4 mt-4"
              initial={{ opacity: 0, y: 15 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <motion.div
                className="h-px bg-gradient-to-r from-transparent to-[#4F9CFF]/60"
                initial={{ width: 0 }}
                animate={isInView ? { width: 80 } : {}}
                transition={{ delay: 0.8, duration: 0.8 }}
              />
              <div className="flex items-center gap-2">
                <motion.div
                  animate={{ rotate: [0, 360] }}
                  transition={{ repeat: Infinity, duration: 8, ease: "linear" }}
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#4F9CFF]" />
                </motion.div>
                <span
                  className="text-[#8888A0] uppercase tracking-[0.3em]"
                  style={{ fontSize: "clamp(0.65rem, 1.2vw, 0.875rem)", fontWeight: 600 }}
                >
                  AI / ML Developer & Builder
                </span>
                <motion.div
                  animate={{ rotate: [0, -360] }}
                  transition={{ repeat: Infinity, duration: 8, ease: "linear" }}
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#8B5CF6]" />
                </motion.div>
              </div>
              <motion.div
                className="h-px bg-gradient-to-l from-transparent to-[#8B5CF6]/60"
                initial={{ width: 0 }}
                animate={isInView ? { width: 80 } : {}}
                transition={{ delay: 0.8, duration: 0.8 }}
              />
            </motion.div>

            {/* Floating accent dots */}
            <motion.div
              className="flex justify-center gap-3 mt-5"
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ delay: 1 }}
            >
              {["#4F9CFF", "#8B5CF6", "#EC4899", "#10B981", "#F59E0B"].map((color, i) => (
                <motion.div
                  key={color}
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ backgroundColor: color }}
                  animate={{ scale: [1, 1.8, 1], opacity: [0.4, 1, 0.4] }}
                  transition={{ repeat: Infinity, duration: 2.5, delay: i * 0.25, ease: "easeInOut" }}
                />
              ))}
            </motion.div>
          </div>

          {/* Middle section: Nav + Social + Info */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.8, duration: 0.7 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-16 pb-12 border-b border-white/[0.06]"
          >
            {/* Quick links */}
            <div>
              <h4 className="text-white mb-5 flex items-center gap-2" style={{ fontSize: "0.8125rem", fontWeight: 600, letterSpacing: "0.15em" }}>
                <div className="w-5 h-px bg-gradient-to-r from-[#4F9CFF] to-transparent" />
                QUICK LINKS
              </h4>
              <div className="grid grid-cols-2 gap-x-8 gap-y-3">
                {navLinks.map((link, i) => (
                  <motion.a
                    key={link.href}
                    href={link.href}
                    className="group flex items-center gap-1.5 text-[#8888A0] hover:text-white transition-all duration-300"
                    style={{ fontSize: "0.875rem" }}
                    whileHover={{ x: 4 }}
                  >
                    <span className="w-0 group-hover:w-2 h-px bg-[#4F9CFF] transition-all duration-300" />
                    {link.label}
                  </motion.a>
                ))}
              </div>
            </div>

            {/* Social */}
            <div className="flex flex-col items-center">
              <h4 className="text-white mb-5 flex items-center gap-2" style={{ fontSize: "0.8125rem", fontWeight: 600, letterSpacing: "0.15em" }}>
                <div className="w-5 h-px bg-gradient-to-r from-[#8B5CF6] to-transparent" />
                CONNECT
              </h4>
              <div className="flex gap-4">
                {socialLinks.map((item, i) => (
                  <motion.a
                    key={item.label}
                    href={item.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    onMouseEnter={() => setHoveredSocial(i)}
                    onMouseLeave={() => setHoveredSocial(null)}
                    whileHover={{ y: -6, scale: 1.15 }}
                    whileTap={{ scale: 0.9 }}
                    className="relative group"
                  >
                    <div
                      className="w-12 h-12 rounded-2xl bg-white/[0.04] border border-white/[0.08] flex items-center justify-center text-[#8888A0] group-hover:text-white transition-all duration-500 group-hover:border-transparent overflow-hidden"
                    >
                      {/* Hover background fill */}
                      <motion.div
                        className="absolute inset-0 rounded-2xl"
                        style={{ backgroundColor: item.color }}
                        initial={{ scale: 0, opacity: 0 }}
                        animate={hoveredSocial === i ? { scale: 1, opacity: 0.15 } : { scale: 0, opacity: 0 }}
                        transition={{ duration: 0.4 }}
                      />
                      <item.icon className="w-5 h-5 relative z-10" />
                    </div>
                    {/* Label tooltip */}
                    <motion.span
                      className="absolute -bottom-7 left-1/2 -translate-x-1/2 text-[#8888A0] whitespace-nowrap pointer-events-none"
                      style={{ fontSize: "0.625rem", fontWeight: 500 }}
                      initial={{ opacity: 0, y: -4 }}
                      animate={hoveredSocial === i ? { opacity: 1, y: 0 } : { opacity: 0, y: -4 }}
                      transition={{ duration: 0.2 }}
                    >
                      {item.label}
                    </motion.span>
                  </motion.a>
                ))}
              </div>
            </div>

            {/* Contact info */}
            <div className="flex flex-col md:items-end">
              <h4 className="text-white mb-5 flex items-center gap-2" style={{ fontSize: "0.8125rem", fontWeight: 600, letterSpacing: "0.15em" }}>
                <div className="w-5 h-px bg-gradient-to-r from-[#EC4899] to-transparent" />
                GET IN TOUCH
              </h4>
              <div className="space-y-3">
                <a href="mailto:jainilkaila@gmail.com" className="flex items-center gap-2.5 text-[#8888A0] hover:text-[#4F9CFF] transition-colors" style={{ fontSize: "0.875rem" }}>
                  <Mail className="w-3.5 h-3.5" />
                  jainilkaila@gmail.com
                </a>
                <div className="flex items-center gap-2.5 text-[#8888A0]" style={{ fontSize: "0.875rem" }}>
                  <Phone className="w-3.5 h-3.5" />
                  +91 8866535911
                </div>
                <div className="flex items-center gap-2.5 text-[#8888A0]" style={{ fontSize: "0.875rem" }}>
                  <MapPin className="w-3.5 h-3.5" />
                  Vadodara, Gujarat, India
                </div>
              </div>
            </div>
          </motion.div>

          {/* Bottom bar */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ delay: 1.2, duration: 0.8 }}
            className="flex flex-col sm:flex-row items-center justify-between gap-4"
          >
            {/* Brand */}
            <a href="#" className="flex items-center gap-2.5 group">
              <motion.div
                className="relative w-8 h-8 rounded-lg bg-gradient-to-br from-[#4F9CFF] to-[#8B5CF6] flex items-center justify-center"
                whileHover={{ rotate: 180, scale: 1.1 }}
                transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              >
                <Sparkles className="w-4 h-4 text-white" />
              </motion.div>
              <span className="text-white" style={{ fontSize: "0.9375rem", fontWeight: 700 }}>
                Jainil<span className="text-[#4F9CFF]">.dev</span>
              </span>
            </a>


            {/* Scroll to top */}
            <motion.button
              onClick={scrollToTop}
              whileHover={{ y: -4, scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="group relative flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/[0.06] hover:border-[#4F9CFF]/30 hover:bg-[#4F9CFF]/5 transition-all duration-500 text-[#8888A0] hover:text-white"
              style={{ fontSize: "0.75rem", fontWeight: 500 }}
            >
              <ArrowUp className="w-3.5 h-3.5 group-hover:-translate-y-0.5 transition-transform duration-300" />
              <span>Back to Top</span>
            </motion.button>
          </motion.div>
        </div>
      </div>
    </footer>
  );
}