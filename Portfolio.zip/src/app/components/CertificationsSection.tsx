import { useRef } from "react";
import { motion, useInView } from "motion/react";
import { Award, ExternalLink, CheckCircle } from "lucide-react";

const certifications = [
  {
    title: "WordPress Developer",
    issuer: "Certified Authority",
    color: "#0073AA",
    gradient: "from-[#0073AA] to-[#38BDF8]",
    icon: "💻",
    skills: ["Theme Dev", "Plugins", "PHP", "CMS"],
  },
  {
    title: "Generative AI with LLMs",
    issuer: "AWS & OpenAI",
    color: "#4F9CFF",
    gradient: "from-[#4F9CFF] to-[#60A5FA]",
    icon: "🧠",
    skills: ["LLMs", "Fine-tuning", "RLHF"],
  },
  {
    title: "AI and ML on Google Cloud",
    issuer: "Google Cloud",
    color: "#10B981",
    gradient: "from-[#10B981] to-[#34D399]",
    icon: "☁️",
    skills: ["TensorFlow", "Vertex AI", "Cloud ML"],
  },
  {
    title: "Introduction to AI",
    issuer: "IBM",
    color: "#8B5CF6",
    gradient: "from-[#8B5CF6] to-[#A78BFA]",
    icon: "🤖",
    skills: ["Neural Networks", "Deep Learning", "AI Ethics"],
  },
  {
    title: "ChatGPT Prompt Engineering",
    issuer: "OpenAI",
    color: "#EC4899",
    gradient: "from-[#EC4899] to-[#F472B6]",
    icon: "⚡",
    skills: ["Prompting", "Chain-of-Thought", "Few-Shot"],
  },
];

export function CertificationsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section id="certifications" className="py-28 relative">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[300px] h-[1px] bg-gradient-to-r from-transparent via-[#10B981]/40 to-transparent" />

      <div className="max-w-7xl mx-auto px-6 relative" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <motion.span
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            className="inline-block px-4 py-1.5 rounded-full bg-[#10B981]/10 border border-[#10B981]/20 text-[#34D399] mb-5"
            style={{ fontSize: "0.8125rem", fontWeight: 600, letterSpacing: "0.1em" }}
          >
            CERTIFICATIONS
          </motion.span>
          <h2 className="text-white" style={{ fontSize: "clamp(1.5rem, 3vw, 2.5rem)", fontWeight: 700 }}>
            Professional{" "}
            <span className="bg-gradient-to-r from-[#10B981] via-[#4F9CFF] to-[#8B5CF6] bg-clip-text text-transparent">
              Certifications
            </span>
          </h2>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-5">
          {certifications.map((cert, index) => (
            <motion.div
              key={cert.title}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.8,
                delay: 0.15 + index * 0.1,
                ease: [0.22, 1, 0.36, 1],
              }}
              whileHover={{
                y: -8,
                scale: 1.02,
                transition: { duration: 0.4, ease: [0.22, 1, 0.36, 1] },
              }}
              className="group relative rounded-2xl overflow-hidden cursor-default"
            >
              {/* Hover border glow */}
              <motion.div
                className="absolute -inset-[1px] rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"
                style={{
                  background: `linear-gradient(135deg, ${cert.color}00, ${cert.color}40, ${cert.color}00)`,
                  backgroundSize: "200% 200%",
                  animation: "gradientShift 3s ease infinite",
                }}
              />

              <div
                className="relative z-10 h-full p-6 rounded-2xl text-center"
                style={{
                  backgroundColor: "rgba(13,13,20,0.9)",
                  border: "1px solid rgba(255,255,255,0.05)",
                  backdropFilter: "blur(12px)",
                }}
              >
                {/* Hover inner glow */}
                <div
                  className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"
                  style={{
                    background: `radial-gradient(circle at 50% 0%, ${cert.color}12, transparent 60%)`,
                  }}
                />

                <div className="relative z-10">
                  {/* Icon + Badge */}
                  <div className="relative inline-block mb-4">
                    <motion.div
                      className="text-4xl"
                      whileHover={{ scale: 1.2, rotate: [0, -10, 10, 0] }}
                      transition={{ duration: 0.5 }}
                    >
                      {cert.icon}
                    </motion.div>
                  </div>

                  {/* Award icon */}
                  <motion.div
                    className={`w-12 h-12 rounded-xl bg-gradient-to-br ${cert.gradient} mx-auto mb-4 flex items-center justify-center shadow-lg`}
                    style={{ boxShadow: `0 4px 20px ${cert.color}25` }}
                    whileHover={{ rotate: [0, -10, 10, 0], scale: 1.1 }}
                    transition={{ duration: 0.5 }}
                  >
                    <Award className="w-6 h-6 text-white" />
                  </motion.div>

                  <h3
                    className="text-white mb-1.5"
                    style={{ fontSize: "0.9375rem", fontWeight: 600, lineHeight: 1.4 }}
                  >
                    {cert.title}
                  </h3>
                  <p style={{ color: cert.color, fontSize: "0.8125rem", fontWeight: 600 }}>
                    {cert.issuer}
                  </p>

                  {/* Skills */}
                  <div className="flex flex-wrap justify-center gap-1.5 mt-4">
                    {cert.skills.map((skill) => (
                      <span
                        key={skill}
                        className="flex items-center gap-1 px-2 py-0.5 rounded-md"
                        style={{
                          fontSize: "0.625rem",
                          fontWeight: 500,
                          color: `${cert.color}CC`,
                          backgroundColor: `${cert.color}10`,
                        }}
                      >
                        <CheckCircle className="w-2.5 h-2.5" />
                        {skill}
                      </span>
                    ))}
                  </div>

                  {/* View button */}
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="mt-5 flex items-center gap-1.5 mx-auto px-4 py-2 rounded-lg text-[#8888A0] hover:text-white transition-all duration-300 bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.06] hover:border-white/[0.12]"
                    style={{ fontSize: "0.75rem", fontWeight: 500 }}
                  >
                    <ExternalLink className="w-3 h-3" />
                    View Certificate
                  </motion.button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}