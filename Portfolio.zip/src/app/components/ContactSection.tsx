import { useState, useRef } from "react";
import { motion, useInView } from "motion/react";
import { Send, Linkedin, Mail, MapPin, CheckCircle2, Sparkles } from "lucide-react";

export function ContactSection() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [submitted, setSubmitted] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
    setForm({ name: "", email: "", message: "" });
  };

  const contactCards = [
    {
      icon: Mail,
      label: "Email",
      value: "jainilkaila@gmail.com",
      href: "mailto:jainilkaila@gmail.com",
      color: "#4F9CFF",
      gradient: "from-[#4F9CFF] to-[#60A5FA]",
    },
    {
      icon: Linkedin,
      label: "LinkedIn",
      value: "Kaila Jainil",
      href: "https://linkedin.com/in/kailajainil",
      color: "#0A66C2",
      gradient: "from-[#0A66C2] to-[#0077B5]",
    },
    {
      icon: MapPin,
      label: "Location",
      value: "Vadodara, Gujarat, India",
      href: "#",
      color: "#8B5CF6",
      gradient: "from-[#8B5CF6] to-[#A78BFA]",
    },
  ];

  return (
    <section id="contact" className="py-28 relative">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[300px] h-[1px] bg-gradient-to-r from-transparent via-[#4F9CFF]/40 to-transparent" />
      <motion.div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#4F9CFF]/5 rounded-full blur-[150px]"
        animate={{ scale: [1, 1.1, 1], opacity: [0.5, 0.8, 0.5] }}
        transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
      />

      <div className="max-w-5xl mx-auto px-6 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="text-center mb-16"
        >
          <motion.span
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            className="inline-block px-4 py-1.5 rounded-full bg-[#4F9CFF]/10 border border-[#4F9CFF]/20 text-[#4F9CFF] mb-5"
            style={{ fontSize: "0.8125rem", fontWeight: 600, letterSpacing: "0.1em" }}
          >
            GET IN TOUCH
          </motion.span>
          <h2 className="text-white mb-4" style={{ fontSize: "clamp(1.5rem, 3vw, 2.5rem)", fontWeight: 700 }}>
            Let's Build Something{" "}
            <span className="bg-gradient-to-r from-[#4F9CFF] via-[#8B5CF6] to-[#EC4899] bg-clip-text text-transparent">
              Amazing Together
            </span>
          </h2>
          <p className="text-[#8888A0] max-w-lg mx-auto" style={{ fontSize: "1rem", lineHeight: 1.7 }}>
            Have a project in mind or want to collaborate? I'd love to hear from you!
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Info cards */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.9, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="lg:col-span-2 space-y-4"
          >
            {contactCards.map((item, index) => (
              <motion.a
                key={item.label}
                href={item.href}
                initial={{ opacity: 0, x: -20 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ delay: 0.3 + index * 0.1 }}
                whileHover={{ x: 5, scale: 1.02 }}
                className="group flex items-center gap-4 p-5 rounded-xl bg-white/[0.03] border border-white/[0.06] hover:border-white/[0.12] transition-all duration-300 overflow-hidden relative"
              >
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500" style={{ background: `linear-gradient(135deg, ${item.color}08, transparent)` }} />
                <motion.div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.gradient} flex items-center justify-center flex-shrink-0 shadow-lg`}
                  style={{ boxShadow: `0 4px 15px ${item.color}25` }}
                  whileHover={{ rotate: [0, -10, 10, 0] }}
                >
                  <item.icon className="w-5 h-5 text-white" />
                </motion.div>
                <div className="relative z-10">
                  <p className="text-[#666]" style={{ fontSize: "0.75rem", fontWeight: 500 }}>{item.label}</p>
                  <p className="text-white group-hover:text-[#4F9CFF] transition-colors" style={{ fontSize: "0.9375rem", fontWeight: 500 }}>{item.value}</p>
                </div>
              </motion.a>
            ))}

            {/* Decorative quote */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={isInView ? { opacity: 1 } : {}}
              transition={{ delay: 0.7 }}
              className="p-5 rounded-xl bg-gradient-to-br from-[#4F9CFF]/5 to-[#8B5CF6]/5 border border-white/[0.06]"
            >
              <Sparkles className="w-5 h-5 text-[#4F9CFF] mb-3" />
              <p className="text-[#8888A0] italic" style={{ fontSize: "0.875rem", lineHeight: 1.6 }}>
                "The best way to predict the future is to build it with AI."
              </p>
              <p className="text-[#555] mt-2" style={{ fontSize: "0.75rem" }}>- Kaila Jainil</p>
            </motion.div>
          </motion.div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.9, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="lg:col-span-3"
          >
            <form onSubmit={handleSubmit} className="relative p-7 rounded-2xl bg-white/[0.03] border border-white/[0.06] space-y-5 overflow-hidden">
              {/* Animated grid pattern */}
              <div
                className="absolute inset-0 opacity-[0.02]"
                style={{
                  backgroundImage: `linear-gradient(rgba(79,156,255,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(79,156,255,0.3) 1px, transparent 1px)`,
                  backgroundSize: "40px 40px",
                }}
              />
              {/* Form glow based on focus */}
              <div
                className="absolute inset-0 opacity-0 transition-opacity duration-700 pointer-events-none"
                style={{
                  opacity: focusedField ? 0.5 : 0,
                  background: "radial-gradient(circle at 50% 50%, rgba(79,156,255,0.05), transparent 70%)",
                }}
              />

              <div className="grid sm:grid-cols-2 gap-5 relative z-10">
                <div>
                  <label className="block text-[#8888A0] mb-2" style={{ fontSize: "0.8125rem", fontWeight: 500 }}>Name</label>
                  <motion.div
                    className="relative"
                    animate={focusedField === "name" ? { scale: 1.01 } : { scale: 1 }}
                  >
                    <input
                      type="text"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      onFocus={() => setFocusedField("name")}
                      onBlur={() => setFocusedField(null)}
                      placeholder="Your name"
                      className="w-full px-4 py-3.5 rounded-xl bg-white/[0.05] border border-white/[0.08] text-white placeholder-[#444] focus:border-[#4F9CFF]/50 focus:bg-white/[0.07] focus:outline-none transition-all duration-300"
                      style={{ fontSize: "0.9375rem" }}
                      required
                    />
                    {focusedField === "name" && (
                      <motion.div
                        className="absolute -inset-[1px] rounded-xl border border-[#4F9CFF]/30 pointer-events-none"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        layoutId="inputFocus"
                      />
                    )}
                  </motion.div>
                </div>
                <div>
                  <label className="block text-[#8888A0] mb-2" style={{ fontSize: "0.8125rem", fontWeight: 500 }}>Email</label>
                  <motion.div
                    className="relative"
                    animate={focusedField === "email" ? { scale: 1.01 } : { scale: 1 }}
                  >
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      onFocus={() => setFocusedField("email")}
                      onBlur={() => setFocusedField(null)}
                      placeholder="your@email.com"
                      className="w-full px-4 py-3.5 rounded-xl bg-white/[0.05] border border-white/[0.08] text-white placeholder-[#444] focus:border-[#4F9CFF]/50 focus:bg-white/[0.07] focus:outline-none transition-all duration-300"
                      style={{ fontSize: "0.9375rem" }}
                      required
                    />
                    {focusedField === "email" && (
                      <motion.div
                        className="absolute -inset-[1px] rounded-xl border border-[#4F9CFF]/30 pointer-events-none"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        layoutId="inputFocus"
                      />
                    )}
                  </motion.div>
                </div>
              </div>
              <div className="relative z-10">
                <label className="block text-[#8888A0] mb-2" style={{ fontSize: "0.8125rem", fontWeight: 500 }}>Message</label>
                <motion.div
                  className="relative"
                  animate={focusedField === "message" ? { scale: 1.005 } : { scale: 1 }}
                >
                  <textarea
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    onFocus={() => setFocusedField("message")}
                    onBlur={() => setFocusedField(null)}
                    placeholder="Tell me about your project..."
                    rows={5}
                    className="w-full px-4 py-3.5 rounded-xl bg-white/[0.05] border border-white/[0.08] text-white placeholder-[#444] focus:border-[#4F9CFF]/50 focus:bg-white/[0.07] focus:outline-none transition-all duration-300 resize-none"
                    style={{ fontSize: "0.9375rem" }}
                    required
                  />
                  {focusedField === "message" && (
                    <motion.div
                      className="absolute -inset-[1px] rounded-xl border border-[#4F9CFF]/30 pointer-events-none"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      layoutId="inputFocus"
                    />
                  )}
                </motion.div>
              </div>
              <motion.button
                type="submit"
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                className="relative z-10 w-full flex items-center justify-center gap-2.5 px-6 py-4 rounded-xl text-white overflow-hidden group"
                style={{ fontWeight: 600, fontSize: "0.9375rem" }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-[#4F9CFF] to-[#8B5CF6]" />
                <div className="absolute inset-0 bg-gradient-to-r from-[#8B5CF6] to-[#EC4899] opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100">
                  <div className="absolute -inset-full h-full w-1/2 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-[-20deg] group-hover:translate-x-[400%] transition-transform duration-1000" />
                </div>
                {submitted ? (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="relative z-10 flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-5 h-5" />
                    Message Sent Successfully!
                  </motion.span>
                ) : (
                  <span className="relative z-10 flex items-center gap-2">
                    <Send className="w-4 h-4" />
                    Send Message
                  </span>
                )}
              </motion.button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}