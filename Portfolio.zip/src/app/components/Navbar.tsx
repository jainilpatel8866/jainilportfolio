import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, Sparkles } from "lucide-react";

const navLinks = [
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Experience", href: "#experience" },
  { label: "Projects", href: "#projects" },
  { label: "Certifications", href: "#certifications" },
  { label: "Contact", href: "#contact" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("");

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 50);
      const sections = navLinks.map((l) => l.href.replace("#", ""));
      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el && el.getBoundingClientRect().top < 200) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <motion.nav
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
        className="fixed top-0 left-0 right-0 z-50 flex justify-center"
      >
        <motion.div
          className="flex items-center justify-between w-full max-w-5xl mx-4 mt-4"
          animate={{
            backgroundColor: scrolled ? "rgba(10,10,10,0.75)" : "rgba(10,10,10,0)",
            backdropFilter: scrolled ? "blur(24px) saturate(180%)" : "blur(0px)",
            borderColor: scrolled ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0)",
            paddingTop: scrolled ? 12 : 16,
            paddingBottom: scrolled ? 12 : 16,
          }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          style={{
            borderWidth: 1,
            borderStyle: "solid",
            borderRadius: 16,
            paddingLeft: 24,
            paddingRight: 24,
          }}
        >
          {/* Logo */}
          <a href="#" className="flex items-center gap-2.5 group">
            <motion.div
              className="relative w-8 h-8 rounded-lg bg-gradient-to-br from-[#4F9CFF] to-[#8B5CF6] flex items-center justify-center"
              whileHover={{ rotate: 180, scale: 1.1 }}
              transition={{ duration: 0.5 }}
            >
              <Sparkles className="w-4 h-4 text-white" />
              <div className="absolute inset-0 rounded-lg bg-gradient-to-br from-[#4F9CFF] to-[#8B5CF6] blur-lg opacity-0 group-hover:opacity-60 transition-opacity duration-500" />
            </motion.div>
            <span className="text-white tracking-tight" style={{ fontSize: "1rem", fontWeight: 700 }}>
              Jainil<span className="text-[#4F9CFF]">.dev</span>
            </span>
          </a>

          {/* Desktop links */}
          <div className="hidden md:flex items-center gap-0.5">
            {navLinks.map((link, i) => {
              const isActive = activeSection === link.href.replace("#", "");
              return (
                <motion.a
                  key={link.href}
                  href={link.href}
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.08 + i * 0.04 }}
                  className="relative px-3.5 py-1.5 rounded-lg transition-colors duration-300"
                  style={{
                    fontSize: "0.8125rem",
                    fontWeight: 500,
                    color: isActive ? "#fff" : "#8888A0",
                  }}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeNav"
                      className="absolute inset-0 rounded-lg"
                      style={{
                        backgroundColor: "rgba(255,255,255,0.06)",
                        border: "1px solid rgba(255,255,255,0.08)",
                      }}
                      transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10 hover:text-white transition-colors duration-300">
                    {link.label}
                  </span>
                </motion.a>
              );
            })}

            <motion.a
              href="#contact"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="relative ml-3 px-5 py-2 rounded-lg text-white overflow-hidden group"
              style={{ fontSize: "0.8125rem", fontWeight: 600 }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-[#4F9CFF] to-[#8B5CF6] rounded-lg" />
              <div className="absolute inset-0 bg-gradient-to-r from-[#8B5CF6] to-[#EC4899] rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100">
                <div className="absolute -inset-full h-full w-1/2 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-[-20deg] group-hover:animate-[shimmer_1.5s_ease-in-out]" />
              </div>
              <span className="relative z-10">Hire Me</span>
            </motion.a>
          </div>

          {/* Mobile toggle */}
          <motion.button
            className="md:hidden text-white p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
            whileTap={{ scale: 0.9 }}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </motion.button>
        </motion.div>
      </motion.nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 pt-24 bg-[#0A0A0A]/95 backdrop-blur-2xl md:hidden"
          >
            <div className="px-8 space-y-1">
              {navLinks.map((link, i) => (
                <motion.a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06 }}
                  className="block py-4 text-[#8888A0] hover:text-white transition-colors border-b border-white/5"
                  style={{ fontSize: "1.125rem", fontWeight: 500 }}
                >
                  <span className="text-[#4F9CFF] mr-3" style={{ fontSize: "0.75rem", fontWeight: 600 }}>
                    0{i + 1}
                  </span>
                  {link.label}
                </motion.a>
              ))}
              <motion.a
                href="#contact"
                onClick={() => setMobileOpen(false)}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="mt-6 block text-center px-5 py-4 rounded-xl bg-gradient-to-r from-[#4F9CFF] to-[#8B5CF6] text-white"
                style={{ fontWeight: 600, fontSize: "1rem" }}
              >
                Hire Me
              </motion.a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
