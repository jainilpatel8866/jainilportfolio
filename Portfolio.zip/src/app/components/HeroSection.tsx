import { useState, useEffect, useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { ArrowDown, FolderOpen, FileDown, Mail, ChevronRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import resumePage1 from "figma:asset/59bc04447b52b0c0ad1feed1ecbf4f14b4a8033f.png";
import resumePage2 from "figma:asset/9ff70a1d66015071bc2fdbc4cfed88994c56a36e.png";

function TypingText({ texts }: { texts: string[] }) {
  const [textIndex, setTextIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = texts[textIndex];
    const timeout = setTimeout(
      () => {
        if (!deleting) {
          if (charIndex < current.length) {
            setCharIndex((c) => c + 1);
          } else {
            setTimeout(() => setDeleting(true), 2000);
          }
        } else {
          if (charIndex > 0) {
            setCharIndex((c) => c - 1);
          } else {
            setDeleting(false);
            setTextIndex((t) => (t + 1) % texts.length);
          }
        }
      },
      deleting ? 30 : 80
    );
    return () => clearTimeout(timeout);
  }, [charIndex, deleting, textIndex, texts]);

  return (
    <span>
      {texts[textIndex].slice(0, charIndex)}
      <motion.span
        animate={{ opacity: [1, 0] }}
        transition={{ repeat: Infinity, duration: 0.6 }}
        className="inline-block w-[3px] h-[1em] bg-[#4F9CFF] ml-0.5 align-text-bottom"
      />
    </span>
  );
}

function CountUp({ target, duration = 2 }: { target: number; duration?: number }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let start = 0;
    const step = target / (duration * 60);
    const interval = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(interval);
      } else {
        setCount(Math.floor(start));
      }
    }, 1000 / 60);
    return () => clearInterval(interval);
  }, [target, duration]);
  return <>{count}</>;
}

function downloadResume() {
  // Download both resume pages
  const link1 = document.createElement("a");
  link1.href = resumePage1;
  link1.download = "Kaila_Jainil_Resume_Page1.png";
  link1.click();

  setTimeout(() => {
    const link2 = document.createElement("a");
    link2.href = resumePage2;
    link2.download = "Kaila_Jainil_Resume_Page2.png";
    link2.click();
  }, 500);
}

export function HeroSection() {
  const heroRef = useRef<HTMLElement>(null);

  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });

  const heroOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 0.5], [1, 0.95]);
  const heroY = useTransform(scrollYProgress, [0, 0.5], [0, 80]);

  return (
    <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Animated background orbs */}
      <div className="absolute inset-0">
        <motion.div
          className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-[#4F9CFF]/12 rounded-full blur-[120px]"
          animate={{ x: [0, 50, 0], y: [0, -30, 0], scale: [1, 1.1, 1] }}
          transition={{ repeat: Infinity, duration: 8, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-[#8B5CF6]/12 rounded-full blur-[120px]"
          animate={{ x: [0, -40, 0], y: [0, 40, 0], scale: [1, 1.15, 1] }}
          transition={{ repeat: Infinity, duration: 10, ease: "easeInOut" }}
        />
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-[#EC4899]/8 rounded-full blur-[100px]"
          animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.6, 0.3] }}
          transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
        />
        {/* Noise grain texture */}
        <div className="absolute inset-0 opacity-[0.015]" style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='1'/%3E%3C/svg%3E\")", backgroundRepeat: "repeat" }} />
        {/* Grid overlay */}
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage: `linear-gradient(rgba(79,156,255,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(79,156,255,0.3) 1px, transparent 1px)`,
            backgroundSize: "60px 60px",
          }}
        />
        {/* Radial gradient fade */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,#0A0A0A_70%)]" />
      </div>

      <motion.div
        style={{ opacity: heroOpacity, scale: heroScale, y: heroY }}
        className="relative z-10 max-w-7xl mx-auto px-6 flex flex-col lg:flex-row items-center gap-12 lg:gap-20"
      >
        {/* Left content */}
        <div className="flex-1 text-center lg:text-left">
          <motion.div
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 mb-6"
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
          >
            <span className="relative w-2 h-2">
              <span className="absolute inset-0 rounded-full bg-green-400 animate-ping" />
              <span className="relative block w-2 h-2 rounded-full bg-green-400" />
            </span>
            <span className="text-[#8888A0]" style={{ fontSize: "0.8125rem" }}>Available for opportunities</span>
            <ChevronRight className="w-3 h-3 text-[#8888A0]" />
          </motion.div>

          <motion.h1
            className="text-white mb-6"
            style={{ fontSize: "clamp(2rem, 5vw, 3.75rem)", fontWeight: 800, lineHeight: 1.05 }}
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 1, ease: [0.22, 1, 0.36, 1] }}
          >
            Building{" "}
            <span className="relative inline-block">
              <span className="bg-gradient-to-r from-[#4F9CFF] via-[#8B5CF6] to-[#EC4899] bg-clip-text text-transparent bg-[length:200%] animate-[gradientShift_3s_ease-in-out_infinite]">
                <TypingText texts={["AI Products", "LLM Solutions", "Automation Tools", "Smart Chatbots"]} />
              </span>
            </span>
            <br />
            That Automate the Future
          </motion.h1>

          <motion.p
            className="text-[#8888A0] max-w-xl mb-8"
            style={{ fontSize: "1.125rem", lineHeight: 1.7 }}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          >
            Results-driven AI/ML Developer passionate about Generative AI, LLMs, UI/UX design, and automation product development. Dedicated to turning complex AI capabilities into real-world solutions. Based in Vadodara, Gujarat, India.
          </motion.p>

          <motion.div
            className="flex flex-wrap gap-4 justify-center lg:justify-start"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          >
            <motion.a
              href="#projects"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.97 }}
              className="group relative flex items-center gap-2 px-7 py-3.5 rounded-xl text-white overflow-hidden"
              style={{ fontWeight: 600, fontSize: "0.9375rem" }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-[#4F9CFF] to-[#8B5CF6]" />
              <div className="absolute inset-0 bg-gradient-to-r from-[#8B5CF6] to-[#EC4899] opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100">
                <div className="absolute -inset-full h-full w-1/2 bg-gradient-to-r from-transparent via-white/25 to-transparent skew-x-[-20deg] group-hover:translate-x-[400%] transition-transform duration-1000" />
              </div>
              <FolderOpen className="w-4 h-4 relative z-10" />
              <span className="relative z-10">View Projects</span>
            </motion.a>
            <motion.a
              href="#"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.97 }}
              className="group relative flex items-center gap-2 px-7 py-3.5 rounded-xl text-white overflow-hidden border border-white/10 hover:border-white/20 transition-colors"
              style={{ fontWeight: 600, fontSize: "0.9375rem" }}
              onClick={(e) => { e.preventDefault(); downloadResume(); }}
            >
              <div className="absolute inset-0 bg-white/0 group-hover:bg-white/[0.06] transition-colors duration-300" />
              <FileDown className="w-4 h-4 relative z-10" />
              <span className="relative z-10">Download Resume</span>
            </motion.a>
            <motion.a
              href="#contact"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.97 }}
              className="group relative flex items-center gap-2 px-7 py-3.5 rounded-xl text-white overflow-hidden border border-white/10 hover:border-[#4F9CFF]/30 transition-colors"
              style={{ fontWeight: 600, fontSize: "0.9375rem" }}
            >
              <div className="absolute inset-0 bg-white/0 group-hover:bg-[#4F9CFF]/5 transition-colors duration-300" />
              <Mail className="w-4 h-4 relative z-10" />
              <span className="relative z-10">Contact Me</span>
            </motion.a>
          </motion.div>

          {/* Stats */}
          <motion.div
            className="flex gap-10 mt-12 justify-center lg:justify-start"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          >
            {[
              { value: 5, suffix: "+", label: "Projects" },
              { value: 3, suffix: "+", label: "Internships" },
              { value: 4, suffix: "+", label: "Certifications" },
            ].map((stat) => (
              <div key={stat.label} className="relative">
                <div className="text-white" style={{ fontSize: "2rem", fontWeight: 800 }}>
                  <CountUp target={stat.value} />{stat.suffix}
                </div>
                <div className="text-[#8888A0]" style={{ fontSize: "0.8125rem" }}>{stat.label}</div>
                <div className="absolute -bottom-2 left-0 w-8 h-[2px] bg-gradient-to-r from-[#4F9CFF] to-transparent rounded-full" />
              </div>
            ))}
          </motion.div>
        </div>

        {/* Right - Avatar with orbiting elements */}
        <motion.div
          className="flex-shrink-0"
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="relative">
            {/* Outer orbit ring */}
            <motion.div
              className="absolute -inset-8 rounded-full border border-dashed border-white/[0.08]"
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
            >
              <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-[#4F9CFF] shadow-lg shadow-[#4F9CFF]/50" />
              <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-[#8B5CF6] shadow-lg shadow-[#8B5CF6]/50" />
            </motion.div>

            {/* Inner orbit ring */}
            <motion.div
              className="absolute -inset-4 rounded-full border border-dashed border-white/[0.05]"
              animate={{ rotate: -360 }}
              transition={{ repeat: Infinity, duration: 15, ease: "linear" }}
            >
              <div className="absolute top-1/2 -right-1 -translate-y-1/2 w-2 h-2 rounded-full bg-[#EC4899] shadow-lg shadow-[#EC4899]/50" />
            </motion.div>

            {/* Glow */}
            <motion.div
              className="absolute -inset-3 bg-gradient-to-br from-[#4F9CFF]/30 to-[#8B5CF6]/30 rounded-full blur-2xl"
              animate={{ opacity: [0.3, 0.6, 0.3], scale: [0.95, 1.05, 0.95] }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
            />

            {/* Avatar */}
            <motion.div
              className="relative w-64 h-64 lg:w-80 lg:h-80 rounded-full overflow-hidden border-2 border-white/10"
              whileHover={{ scale: 1.03 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1770795945584-6d5046ffe47c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBSSUyMGRldmVsb3BlciUyMHBvcnRyYWl0JTIwZGFyayUyMGJhY2tncm91bmR8ZW58MXx8fHwxNzczMzk5MzkzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Kaila Jainil"
                className="w-full h-full object-cover"
              />
              {/* Overlay shimmer */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A]/40 via-transparent to-transparent" />
            </motion.div>

            {/* Floating badges */}
            <motion.div
              className="absolute -right-6 top-6 px-4 py-2 rounded-xl bg-[#0F0F14]/90 border border-white/10 backdrop-blur-xl shadow-xl"
              animate={{ y: [0, -10, 0], rotate: [0, 2, 0] }}
              transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
            >
              <span style={{ fontSize: "0.8125rem", fontWeight: 500 }}>🤖 AI/ML Dev</span>
            </motion.div>
            <motion.div
              className="absolute -left-6 bottom-16 px-4 py-2 rounded-xl bg-[#0F0F14]/90 border border-white/10 backdrop-blur-xl shadow-xl"
              animate={{ y: [0, 10, 0], rotate: [0, -2, 0] }}
              transition={{ repeat: Infinity, duration: 3.5, ease: "easeInOut" }}
            >
              <span style={{ fontSize: "0.8125rem", fontWeight: 500 }}>⚡ Gen AI</span>
            </motion.div>
            <motion.div
              className="absolute -right-2 bottom-4 px-4 py-2 rounded-xl bg-[#0F0F14]/90 border border-white/10 backdrop-blur-xl shadow-xl"
              animate={{ y: [0, -6, 0], x: [0, 4, 0] }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
            >
              <span style={{ fontSize: "0.8125rem", fontWeight: 500 }}>🚀 Builder</span>
            </motion.div>
          </div>
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        animate={{ y: [0, 8, 0], opacity: [0.5, 1, 0.5] }}
        transition={{ repeat: Infinity, duration: 2 }}
      >
        <span className="text-[#8888A0]" style={{ fontSize: "0.6875rem", letterSpacing: "0.1em" }}>SCROLL</span>
        <ArrowDown className="w-4 h-4 text-[#4F9CFF]" />
      </motion.div>
    </section>
  );
}