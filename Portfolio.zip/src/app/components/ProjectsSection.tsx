import { useRef, useState } from "react";
import { motion, useInView, AnimatePresence } from "motion/react";
import { ExternalLink, Github, ArrowUpRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const projects = [
  {
    title: "Emotion to Story",
    description: "Built a web application that transforms user emotions into creative stories. Designed a simple, user-friendly interface for emotion-based input with meaningful and personalized storytelling.",
    tags: ["Python", "OpenAI", "NLP", "Streamlit"],
    image: "https://images.unsplash.com/photo-1639104796286-9d5d0dd11430?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBSSUyMHN0b3J5dGVsbGluZyUyMHRlY2hub2xvZ3klMjBhYnN0cmFjdHxlbnwxfHx8fDE3NzMzOTkzOTN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    color: "#4F9CFF",
    gradient: "from-[#4F9CFF] to-[#60A5FA]",
  },
  {
    title: "BizEase",
    description: "Engineered a project to streamline business professionals' lives by enhancing their database chat experience using Python, LangChain, OpenAI, Grouq, PandasAI, and MySQL.",
    tags: ["LangChain", "OpenAI", "SQL", "PandasAI", "Python"],
    image: "https://images.unsplash.com/photo-1721593979313-8661afd501c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXRhYmFzZSUyMGRhc2hib2FyZCUyMEFJJTIwYXNzaXN0YW50fGVufDF8fHx8MTc3MzM5OTM5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    color: "#8B5CF6",
    gradient: "from-[#8B5CF6] to-[#A78BFA]",
  },
  {
    title: "Chat with PDF & URL",
    description: "Developed intuitive chat-based features that enable users to interact with web content and PDFs conversationally using HuggingFace, OpenAI, Bs4, LangChain, VectorDB, and Python.",
    tags: ["RAG", "LangChain", "HuggingFace", "VectorDB"],
    image: "https://images.unsplash.com/photo-1676573408178-a5f280c3a320?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxQREYlMjBkb2N1bWVudCUyMEFJJTIwY2hhdCUyMGludGVyZmFjZXxlbnwxfHx8fDE3NzMzOTkzOTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    color: "#EC4899",
    gradient: "from-[#EC4899] to-[#F472B6]",
  },
  {
    title: "TryMe",
    description: "Pioneered a project where users upload a full-body picture and select clothes to virtually try on. Built with Hugging Face, open-source LLMs, Streamlit, and FastAPI.",
    tags: ["Computer Vision", "Hugging Face", "Streamlit", "FastAPI"],
    image: "https://images.unsplash.com/photo-1601401031947-9cdea53e4886?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aXJ0dWFsJTIwdHJ5JTIwb24lMjBmYXNoaW9uJTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NzMzOTkzOTV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    color: "#10B981",
    gradient: "from-[#10B981] to-[#34D399]",
  },
  {
    title: "Text to Image & Video Generator",
    description: "Crafted an innovative application that transforms user-generated creative prompts into high-quality images and videos using Stable Diffuser, Flux Koda, DALL-E, ByteDance, AnimateLCM, and LangChain.",
    tags: ["Stable Diffusion", "DALL-E", "FastAPI", "LangChain"],
    image: "https://images.unsplash.com/photo-1640236405405-61ca9f9bc4d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBSSUyMGltYWdlJTIwZ2VuZXJhdGlvbiUyMGNyZWF0aXZlfGVufDF8fHx8MTc3MzM5OTM5NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    color: "#F59E0B",
    gradient: "from-[#F59E0B] to-[#FBBF24]",
  },
];

function ProjectCard({
  project,
  index,
  isInView,
  featured,
}: {
  project: (typeof projects)[0];
  index: number;
  isInView: boolean;
  featured?: boolean;
}) {
  const [hovered, setHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50, scale: 0.95 }}
      animate={isInView ? { opacity: 1, y: 0, scale: 1 } : {}}
      transition={{ delay: 0.15 + index * 0.1, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className={`group relative rounded-2xl overflow-hidden cursor-pointer ${
        featured ? "md:col-span-2 md:row-span-2" : ""
      }`}
    >
      {/* Animated border glow */}
      <motion.div
        className="absolute -inset-[1px] rounded-2xl z-0"
        style={{
          background: `linear-gradient(135deg, ${project.color}00, ${project.color}50, ${project.color}00)`,
          backgroundSize: "200% 200%",
        }}
        animate={
          hovered
            ? { opacity: 1, backgroundPosition: ["0% 0%", "100% 100%"] }
            : { opacity: 0 }
        }
        transition={{ duration: 1.5, repeat: hovered ? Infinity : 0, ease: "linear" }}
      />

      <div className="relative z-10 bg-[#0D0D14] rounded-2xl overflow-hidden h-full flex flex-col">
        {/* Image */}
        <div className={`relative overflow-hidden ${featured ? "h-72 md:h-full md:min-h-[300px]" : "h-48"}`}>
          <motion.div
            animate={hovered ? { scale: 1.08 } : { scale: 1 }}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="w-full h-full"
          >
            <ImageWithFallback
              src={project.image}
              alt={project.title}
              className="w-full h-full object-cover"
            />
          </motion.div>

          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D14] via-[#0D0D14]/30 to-transparent" />

          {/* Color overlay on hover */}
          <motion.div
            className="absolute inset-0"
            style={{ background: `linear-gradient(135deg, ${project.color}10, transparent)` }}
            animate={{ opacity: hovered ? 1 : 0 }}
            transition={{ duration: 0.4 }}
          />

          {/* Hover actions */}
          <AnimatePresence>
            {hovered && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/30 backdrop-blur-[2px] flex items-center justify-center gap-3"
              >
                <motion.button
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 20, opacity: 0 }}
                  transition={{ delay: 0.05 }}
                  whileHover={{ scale: 1.15 }}
                  className="w-11 h-11 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center hover:bg-white/20 transition-colors"
                >
                  <Github className="w-5 h-5 text-white" />
                </motion.button>
                <motion.button
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 20, opacity: 0 }}
                  transition={{ delay: 0.1 }}
                  whileHover={{ scale: 1.15 }}
                  className="w-11 h-11 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center hover:bg-white/20 transition-colors"
                >
                  <ExternalLink className="w-5 h-5 text-white" />
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Project number */}
          <div className="absolute top-4 left-4">
            <span
              className="px-2.5 py-1 rounded-md backdrop-blur-md"
              style={{
                fontSize: "0.65rem",
                fontWeight: 700,
                letterSpacing: "0.05em",
                color: "rgba(255,255,255,0.5)",
                backgroundColor: "rgba(0,0,0,0.3)",
                border: "1px solid rgba(255,255,255,0.1)",
              }}
            >
              0{index + 1}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 flex-1 flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <motion.div
                className="w-2.5 h-2.5 rounded-full"
                style={{ backgroundColor: project.color, boxShadow: `0 0 8px ${project.color}60` }}
                animate={{ scale: [1, 1.3, 1] }}
                transition={{ repeat: Infinity, duration: 2, delay: index * 0.3 }}
              />
              <h3 className="text-white" style={{ fontSize: "1.0625rem", fontWeight: 600 }}>{project.title}</h3>
            </div>
            <motion.div
              animate={hovered ? { x: 3, y: -3 } : { x: 0, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <ArrowUpRight className="w-4 h-4 text-[#8888A0] group-hover:text-white transition-colors duration-300" />
            </motion.div>
          </div>
          <p className="text-[#8888A0] mb-5 flex-1" style={{ fontSize: "0.875rem", lineHeight: 1.6 }}>
            {project.description}
          </p>
          <div className="flex flex-wrap gap-2">
            {project.tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1.5 rounded-lg text-[#c8c8d8]"
                style={{
                  fontSize: "0.6875rem",
                  fontWeight: 500,
                  backgroundColor: `${project.color}10`,
                  border: `1px solid ${project.color}20`,
                }}
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export function ProjectsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section id="projects" className="py-28 relative">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[300px] h-[1px] bg-gradient-to-r from-transparent via-[#EC4899]/40 to-transparent" />
      <motion.div
        className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-[#4F9CFF]/5 rounded-full blur-[150px]"
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ repeat: Infinity, duration: 8, ease: "easeInOut" }}
      />

      <div className="max-w-7xl mx-auto px-6 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <motion.span
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            className="inline-block px-4 py-1.5 rounded-full bg-[#EC4899]/10 border border-[#EC4899]/20 text-[#F472B6] mb-5"
            style={{ fontSize: "0.8125rem", fontWeight: 600, letterSpacing: "0.1em" }}
          >
            FEATURED WORK
          </motion.span>
          <h2 className="text-white mb-4" style={{ fontSize: "clamp(1.5rem, 3vw, 2.5rem)", fontWeight: 700 }}>
            Projects That{" "}
            <span className="bg-gradient-to-r from-[#4F9CFF] via-[#8B5CF6] to-[#EC4899] bg-clip-text text-transparent">
              Push Boundaries
            </span>
          </h2>
          <p className="text-[#8888A0] max-w-xl mx-auto" style={{ fontSize: "1rem", lineHeight: 1.7 }}>
            A showcase of my AI-powered applications and cutting-edge tools
          </p>
        </motion.div>

        {/* Featured Bento Grid */}
        <div className="grid md:grid-cols-3 gap-6 auto-rows-auto">
          {/* Featured first project */}
          <ProjectCard
            project={projects[0]}
            index={0}
            isInView={isInView}
            featured
          />
          {/* Remaining projects */}
          {projects.slice(1).map((project, i) => (
            <ProjectCard
              key={project.title}
              project={project}
              index={i + 1}
              isInView={isInView}
            />
          ))}
        </div>
      </div>
    </section>
  );
}