import { useRef } from "react";
import { motion, useInView } from "motion/react";
import { Briefcase, Calendar, MapPin } from "lucide-react";

const experiences = [
  {
    role: "AI/ML Intern",
    company: "Appendo Consulting and Services",
    period: "Oct 2025 - Present",
    location: "Gujarat",
    description: "Spearheaded AI and machine learning projects achieving 30% improvement in operational efficiency. Built PDF ChatBot, website URL ChatBots, resume converters, and image generation tools. Deployed 'Chat with Database' using Hugging Face, LangChain, OpenAI, GroqAI, and Azure.",
    tags: ["AI/ML", "Chatbots", "LLMs", "LangChain", "Azure"],
    color: "#4F9CFF",
    gradient: "from-[#4F9CFF] to-[#60A5FA]",
  },
  {
    role: "AI/ML Intern",
    company: "YBI Foundation",
    period: "Dec 2024 - Jan 2025",
    location: "Online",
    description: "Worked on real-world datasets to perform data cleaning, analysis, and feature engineering. Implemented AI/ML workflows including preprocessing, model training, testing, and performance evaluation with clear metrics.",
    tags: ["Machine Learning", "Data Analysis", "Python", "Feature Engineering"],
    color: "#8B5CF6",
    gradient: "from-[#8B5CF6] to-[#A78BFA]",
  },
  {
    role: "WordPress & Frontend Intern",
    company: "The Codetech Solutions",
    period: "Jun 2025 - Jul 2025",
    location: "Gujarat",
    description: "Developed and customized WordPress websites using themes, plugins, and custom code. Built optimized frontend components with HTML, CSS, JavaScript. Improved website speed, SEO structure, and cross-browser compatibility.",
    tags: ["WordPress", "Frontend", "SEO", "Performance"],
    color: "#EC4899",
    gradient: "from-[#EC4899] to-[#F472B6]",
  },
];

export function ExperienceSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section id="experience" className="py-28 relative">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[300px] h-[1px] bg-gradient-to-r from-transparent via-[#4F9CFF]/40 to-transparent" />
      <motion.div
        className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#8B5CF6]/5 rounded-full blur-[150px]"
        animate={{ y: [0, 30, 0] }}
        transition={{ repeat: Infinity, duration: 8, ease: "easeInOut" }}
      />

      <div className="max-w-5xl mx-auto px-6 relative z-10" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="text-center mb-16"
        >
          <motion.span
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            className="inline-block px-4 py-1.5 rounded-full bg-[#4F9CFF]/10 border border-[#4F9CFF]/20 text-[#4F9CFF] mb-5"
            style={{ fontSize: "0.8125rem", fontWeight: 600, letterSpacing: "0.1em" }}
          >
            EXPERIENCE
          </motion.span>
          <h2 className="text-white" style={{ fontSize: "clamp(1.5rem, 3vw, 2.5rem)", fontWeight: 700 }}>
            Professional{" "}
            <span className="bg-gradient-to-r from-[#4F9CFF] via-[#8B5CF6] to-[#EC4899] bg-clip-text text-transparent">
              Journey
            </span>
          </h2>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Animated vertical line */}
          <motion.div
            className="absolute left-6 md:left-1/2 md:-translate-x-px top-0 w-[2px]"
            style={{
              background: "linear-gradient(to bottom, #4F9CFF, #8B5CF6, #EC4899, transparent)",
            }}
            initial={{ height: "0%" }}
            animate={isInView ? { height: "100%" } : {}}
            transition={{ duration: 2, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
          />

          {experiences.map((exp, index) => (
            <motion.div
              key={exp.company}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.3 + index * 0.25, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
              className={`relative flex items-start gap-8 mb-16 last:mb-0 ${
                index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
              }`}
            >
              {/* Timeline dot */}
              <div className="absolute left-6 md:left-1/2 -translate-x-1/2 mt-7 z-10">
                <motion.div
                  className="relative w-4 h-4 rounded-full border-[3px]"
                  style={{ borderColor: exp.color, backgroundColor: "#0A0A0A" }}
                  whileInView={{ scale: [1, 1.3, 1] }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.6 + index * 0.2, duration: 0.5 }}
                >
                  <div className="absolute -inset-2 rounded-full animate-ping opacity-20" style={{ backgroundColor: exp.color }} />
                  <div className="absolute -inset-4 rounded-full opacity-10" style={{ backgroundColor: exp.color, filter: "blur(8px)" }} />
                </motion.div>
              </div>

              {/* Card */}
              <div className={`ml-14 md:ml-0 md:w-[calc(50%-2.5rem)] ${index % 2 === 0 ? "md:pr-0" : "md:pl-0"}`}>
                <motion.div
                  whileHover={{ y: -5, scale: 1.02, transition: { duration: 0.4, ease: [0.22, 1, 0.36, 1] } }}
                  className="group relative p-8 rounded-3xl bg-white/[0.02] border border-white/[0.05] hover:bg-white/[0.04] hover:border-white/[0.15] hover:shadow-[0_0_30px_rgba(139,92,246,0.15)] transition-all duration-500 overflow-hidden backdrop-blur-xl"
                >
                  {/* Top accent bar */}
                  <div className={`absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r ${exp.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
                  
                  {/* Soft animated corner glow */}
                  <div 
                    className="absolute -top-12 -right-12 w-32 h-32 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-700 blur-[30px]" 
                    style={{ backgroundColor: `${exp.color}40` }} 
                  />
                  <div 
                    className="absolute -bottom-12 -left-12 w-32 h-32 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-700 delay-100 blur-[30px]" 
                    style={{ backgroundColor: `${exp.color}20` }} 
                  />

                  {/* Side accent */}
                  <div
                    className={`absolute top-0 ${index % 2 === 0 ? "right-0" : "left-0"} w-[3px] h-0 group-hover:h-full transition-all duration-700`}
                    style={{ background: `linear-gradient(to bottom, ${exp.color}, transparent)` }}
                  />

                  <div className="relative z-10">
                    <div className="flex items-start gap-3 mb-3">
                      <motion.div
                        className={`w-11 h-11 rounded-xl bg-gradient-to-br ${exp.gradient} flex items-center justify-center shadow-lg flex-shrink-0`}
                        style={{ boxShadow: `0 4px 15px ${exp.color}30` }}
                        whileHover={{ rotate: [0, -10, 10, 0] }}
                      >
                        <Briefcase className="w-5 h-5 text-white" />
                      </motion.div>
                      <div>
                        <h3 className="text-white" style={{ fontSize: "1.0625rem", fontWeight: 600 }}>{exp.role}</h3>
                        <p style={{ color: exp.color, fontSize: "0.875rem", fontWeight: 600 }}>{exp.company}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 mb-3">
                      <span className="flex items-center gap-1 text-[#666]" style={{ fontSize: "0.75rem" }}>
                        <Calendar className="w-3 h-3" /> {exp.period}
                      </span>
                      <span className="flex items-center gap-1 text-[#666]" style={{ fontSize: "0.75rem" }}>
                        <MapPin className="w-3 h-3" /> {exp.location}
                      </span>
                    </div>

                    <p className="text-[#8888A0] mb-5" style={{ fontSize: "0.9rem", lineHeight: 1.7 }}>{exp.description}</p>

                    <div className="flex flex-wrap gap-2 mt-2">
                      {exp.tags.map((tag, i) => (
                        <motion.span
                          key={tag}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={isInView ? { opacity: 1, scale: 1 } : {}}
                          transition={{ delay: 0.6 + i * 0.1, duration: 0.4 }}
                          whileHover={{ scale: 1.05, y: -2 }}
                          className="px-3 py-1.5 rounded-full text-[#E8E8ED] transition-all duration-300 backdrop-blur-md cursor-default"
                          style={{ 
                            fontSize: "0.75rem", 
                            fontWeight: 500, 
                            backgroundColor: `${exp.color}15`, 
                            border: `1px solid ${exp.color}30`,
                            boxShadow: `0 2px 8px ${exp.color}10` 
                          }}
                        >
                          {tag}
                        </motion.span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}