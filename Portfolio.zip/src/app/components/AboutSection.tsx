import { useRef } from "react";
import { motion, useInView } from "motion/react";
import { Brain, Cpu, Zap, ArrowRight } from "lucide-react";

const highlights = [
  {
    icon: Brain,
    title: "AI Product Builder",
    description: "Crafting intelligent products powered by LLMs, RAG pipelines, and advanced AI architectures.",
    gradient: "from-[#4F9CFF] to-[#60A5FA]",
    shadowColor: "shadow-[#4F9CFF]/20",
    borderHover: "#4F9CFF",
  },
  {
    icon: Cpu,
    title: "Generative AI Developer",
    description: "Building applications with GPT, Claude, Gemini, and cutting-edge generative models.",
    gradient: "from-[#8B5CF6] to-[#A78BFA]",
    shadowColor: "shadow-[#8B5CF6]/20",
    borderHover: "#8B5CF6",
  },
  {
    icon: Zap,
    title: "Automation Engineer",
    description: "Designing automation workflows with n8n, Zapier, and Make.com for maximum efficiency.",
    gradient: "from-[#EC4899] to-[#F472B6]",
    shadowColor: "shadow-[#EC4899]/20",
    borderHover: "#EC4899",
  },
];

export function AboutSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section id="about" className="py-28 relative">
      {/* Section divider glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[300px] h-[1px] bg-gradient-to-r from-transparent via-[#4F9CFF]/40 to-transparent" />

      {/* Floating background accent */}
      <motion.div
        className="absolute top-1/3 right-0 w-[400px] h-[400px] bg-[#4F9CFF]/[0.04] rounded-full blur-[150px]"
        animate={{ y: [0, -30, 0] }}
        transition={{ repeat: Infinity, duration: 8, ease: "easeInOut" }}
      />

      <div className="max-w-7xl mx-auto px-6 relative" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="text-center mb-16"
        >
          <motion.span
            initial={{ opacity: 0, scale: 0.8, y: 10 }}
            animate={isInView ? { opacity: 1, scale: 1, y: 0 } : {}}
            transition={{ delay: 0.1, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="inline-block px-4 py-1.5 rounded-full bg-[#4F9CFF]/10 border border-[#4F9CFF]/20 text-[#4F9CFF] mb-5"
            style={{ fontSize: "0.8125rem", fontWeight: 600, letterSpacing: "0.1em" }}
          >
            ABOUT ME
          </motion.span>
          <h2 className="text-white mb-5" style={{ fontSize: "clamp(1.5rem, 3vw, 2.5rem)", fontWeight: 700, lineHeight: 1.2 }}>
            Passionate About{" "}
            <span className="relative inline-block">
              <span className="bg-gradient-to-r from-[#4F9CFF] via-[#8B5CF6] to-[#EC4899] bg-clip-text text-transparent">
                Building the Future
              </span>
              <motion.div
                className="absolute -bottom-1 left-0 h-[2px] bg-gradient-to-r from-[#4F9CFF] to-[#8B5CF6] rounded-full"
                initial={{ width: 0 }}
                animate={isInView ? { width: "100%" } : {}}
                transition={{ delay: 0.6, duration: 1, ease: [0.22, 1, 0.36, 1] }}
              />
            </span>
          </h2>
          <motion.p
            className="text-[#8888A0] max-w-2xl mx-auto"
            style={{ fontSize: "1.0625rem", lineHeight: 1.8 }}
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.3, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            I'm a Computer Science diploma student with a deep focus on Artificial Intelligence, Large Language Models, LangChain, and automation. I love turning complex AI capabilities into real-world products that solve meaningful problems.
          </motion.p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {highlights.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.8,
                delay: 0.3 + index * 0.15,
                ease: [0.22, 1, 0.36, 1],
              }}
              whileHover={{ y: -8, scale: 1.02, transition: { duration: 0.4, ease: [0.22, 1, 0.36, 1] } }}
              className={`group relative p-7 rounded-2xl bg-white/[0.03] border border-white/[0.06] transition-all duration-700 cursor-default overflow-hidden`}
            >
              {/* Hover glow */}
              <div
                className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-all duration-700"
                style={{ background: `radial-gradient(circle at 50% 50%, ${item.borderHover}12, transparent 70%)` }}
              />
              {/* Animated border on hover */}
              <div
                className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"
                style={{ boxShadow: `inset 0 0 0 1px ${item.borderHover}40` }}
              />
              {/* Corner accent */}
              <div className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-br ${item.gradient} opacity-0 group-hover:opacity-[0.07] rounded-bl-full transition-opacity duration-700`} />

              {/* Top accent line */}
              <div className={`absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r ${item.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500 scale-x-0 group-hover:scale-x-100 origin-left`} style={{ transition: "opacity 0.5s, transform 0.7s cubic-bezier(0.22, 1, 0.36, 1)" }} />

              <div className="relative z-10">
                <motion.div
                  className={`w-14 h-14 rounded-xl bg-gradient-to-br ${item.gradient} flex items-center justify-center mb-5 ${item.shadowColor} shadow-lg`}
                  whileHover={{ rotate: [0, -8, 8, 0], scale: 1.1 }}
                  transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                >
                  <item.icon className="w-7 h-7 text-white" />
                </motion.div>
                <h3 className="text-white mb-3" style={{ fontSize: "1.125rem", fontWeight: 600 }}>{item.title}</h3>
                <p className="text-[#8888A0] mb-4" style={{ fontSize: "0.9375rem", lineHeight: 1.6 }}>{item.description}</p>
                <div className="flex items-center gap-1 text-[#8888A0] group-hover:text-white transition-colors duration-500" style={{ fontSize: "0.8125rem", fontWeight: 500 }}>
                  Learn more <ArrowRight className="w-3 h-3 group-hover:translate-x-1.5 transition-transform duration-500" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Tech marquee strip */}
        <motion.div
          className="mt-14 overflow-hidden relative"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 0.8, duration: 1 }}
        >
          <div className="absolute left-0 top-0 bottom-0 w-24 z-10" style={{ background: "linear-gradient(to right, #0A0A0A, transparent)" }} />
          <div className="absolute right-0 top-0 bottom-0 w-24 z-10" style={{ background: "linear-gradient(to left, #0A0A0A, transparent)" }} />
          <motion.div
            className="flex gap-6 w-max"
            animate={{ x: [0, "-50%"] }}
            transition={{ x: { repeat: Infinity, duration: 25, ease: "linear" } }}
          >
            {[...Array(2)].flatMap((_, dup) =>
              ["AI / ML", "Python", "LLMs", "Gen AI", "LangChain", "RAG", "OpenAI", "Automation", "NLP", "Agents"].map((t, i) => (
                <span
                  key={`${dup}-${i}`}
                  className="text-[#3a3a50] whitespace-nowrap"
                  style={{ fontSize: "0.75rem", fontWeight: 600, letterSpacing: "0.15em", textTransform: "uppercase" as const }}
                >
                  {t} <span className="text-[#4F9CFF]/40 mx-2">&#x2022;</span>
                </span>
              ))
            )}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}