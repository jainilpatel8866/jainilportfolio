import { useRef, useState, useEffect, useCallback } from "react";
import { motion, useInView, animate } from "motion/react";
import { Cpu, Network, Bot, Terminal, Sparkles } from "lucide-react";

/* ─── Data ─────────────────────────────────────────────────────── */
const groups = [
  {
    label: "Core AI",
    icon: Cpu,
    color: "#4F9CFF",
    colorRgb: "79,156,255",
    skills: [
      { name: "AI / ML", emoji: "🤖" },
      { name: "Python", emoji: "🐍" },
      { name: "LLMs", emoji: "🧠" },
      { name: "Gen AI", emoji: "⚡" },
    ],
  },
  {
    label: "Engineering",
    icon: Network,
    color: "#8B5CF6",
    colorRgb: "139,92,246",
    skills: [
      { name: "Prompt Eng", emoji: "✍️" },
      { name: "OpenAI API", emoji: "🔮" },
      { name: "LangChain", emoji: "🔗" },
      { name: "RAG", emoji: "📚" },
      { name: "NLP", emoji: "💬" },
      { name: "Agents", emoji: "🤝" },
    ],
  },
  {
    label: "AI Tools",
    icon: Bot,
    color: "#EC4899",
    colorRgb: "236,72,153",
    skills: [
      { name: "ChatGPT", emoji: "💬" },
      { name: "Claude", emoji: "🧠" },
      { name: "Gemini", emoji: "✨" },
      { name: "Midjourney", emoji: "🎨" },
      { name: "Runway ML", emoji: "🎬" },
      { name: "ElevenLabs", emoji: "🎤" },
      { name: "Synthesia", emoji: "🎥" },
    ],
  },
  {
    label: "DevOps & Web",
    icon: Terminal,
    color: "#10B981",
    colorRgb: "16,185,129",
    skills: [
      { name: "WordPress", emoji: "🖥️" },
      { name: "Automation", emoji: "⚙️" },
      { name: "MySQL", emoji: "🗄️" },
      { name: "Front-end", emoji: "🌐" },
      { name: "Git", emoji: "📦" },
      { name: "n8n", emoji: "⚡" },
      { name: "Zapier", emoji: "🔗" },
      { name: "Make.com", emoji: "🛠" },
    ],
  },
];

/* ─── Animated Counter ─────────────────────────────────────────── */
function AnimatedCounter({ target, isInView }: { target: number; isInView: boolean }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!isInView) return;
    const ctrl = animate(0, target, {
      duration: 1.8,
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (v) => setCount(Math.floor(v)),
    });
    return ctrl.stop;
  }, [isInView, target]);
  return <>{count}</>;
}

/* ─── Floating Background Orb ──────────────────────────────────── */
function FloatingOrb({ color, size, left, top, duration, delay }: {
  color: string; size: number; left: string; top: string; duration: number; delay: number;
}) {
  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{ width: size, height: size, left, top, background: color, filter: `blur(${size * 0.4}px)` }}
      animate={{
        x: [0, 30, -20, 15, 0],
        y: [0, -25, 20, -10, 0],
        scale: [1, 1.3, 0.85, 1.15, 1],
        opacity: [0.15, 0.35, 0.2, 0.4, 0.15],
      }}
      transition={{ duration, delay, repeat: Infinity, ease: "easeInOut" }}
    />
  );
}

/* ─── Particle Spark (on pill click) ───────────────────────────── */
interface Spark { id: number; angle: number; dist: number }
function SparkBurst({ sparks, color, originX, originY }: {
  sparks: Spark[]; color: string; originX: number; originY: number;
}) {
  return (
    <>
      {sparks.map((s) => (
        <motion.div
          key={s.id}
          className="absolute rounded-full pointer-events-none z-50"
          style={{ width: 5, height: 5, background: color, left: originX, top: originY, boxShadow: `0 0 6px ${color}` }}
          initial={{ x: 0, y: 0, scale: 1, opacity: 1 }}
          animate={{
            x: Math.cos(s.angle) * s.dist,
            y: Math.sin(s.angle) * s.dist,
            scale: 0,
            opacity: 0,
          }}
          transition={{ duration: 0.65, ease: "easeOut" }}
        />
      ))}
    </>
  );
}

/* ─── Magnetic Skill Pill ──────────────────────────────────────── */
function MagneticPill({ skill, color, colorRgb, isInView, entryDelay, cardHovered }: {
  skill: { name: string; emoji: string };
  color: string; colorRgb: string;
  isInView: boolean; entryDelay: number; cardHovered: boolean;
}) {
  const pillRef = useRef<HTMLDivElement>(null);
  const [mag, setMag] = useState({ x: 0, y: 0 });
  const [hovered, setHovered] = useState(false);
  const [sparks, setSparks] = useState<Spark[]>([]);
  const [sparkOrigin, setSparkOrigin] = useState({ x: 0, y: 0 });

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    const rect = pillRef.current?.getBoundingClientRect();
    if (!rect) return;
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = e.clientX - cx;
    const dy = e.clientY - cy;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < 70) {
      setMag({ x: dx * 0.25, y: dy * 0.25 });
    }
  }, []);

  const handleMouseLeave = useCallback(() => {
    setMag({ x: 0, y: 0 });
    setHovered(false);
  }, []);

  const handleClick = useCallback((e: React.MouseEvent) => {
    const rect = pillRef.current?.getBoundingClientRect();
    if (!rect) return;
    const ox = e.clientX - rect.left;
    const oy = e.clientY - rect.top;
    setSparkOrigin({ x: ox, y: oy });
    const newSparks: Spark[] = Array.from({ length: 10 }, (_, i) => ({
      id: Date.now() + i,
      angle: (i / 10) * Math.PI * 2 + Math.random() * 0.5,
      dist: 30 + Math.random() * 30,
    }));
    setSparks(newSparks);
    setTimeout(() => setSparks([]), 700);
  }, []);

  const glowPulse = cardHovered
    ? `0 0 12px rgba(${colorRgb},0.5), 0 0 24px rgba(${colorRgb},0.2)`
    : "none";

  return (
    <motion.div
      ref={pillRef}
      initial={{ opacity: 0, scale: 0.75, filter: "blur(6px)" }}
      animate={isInView ? { opacity: 1, scale: 1, filter: "blur(0px)" } : {}}
      transition={{ duration: 0.45, delay: entryDelay, ease: [0.22, 1, 0.36, 1] }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={handleMouseLeave}
      onClick={handleClick}
      className="relative cursor-pointer select-none"
      style={{
        x: mag.x, y: mag.y,
        transition: hovered ? undefined : "transform 0.4s ease",
      }}
    >
      {/* Spark burst */}
      <SparkBurst sparks={sparks} color={color} originX={sparkOrigin.x} originY={sparkOrigin.y} />

      {/* Pill */}
      <motion.div
        whileHover={{ scale: 1.12, y: -3 }}
        transition={{ type: "spring", stiffness: 400, damping: 20 }}
        className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-full overflow-hidden"
        style={{
          background: hovered
            ? `rgba(${colorRgb},0.18)`
            : `rgba(${colorRgb},0.08)`,
          border: `1px solid rgba(${colorRgb},${hovered ? 0.5 : 0.2})`,
          color: color,
          boxShadow: glowPulse,
          transition: "background 0.2s, border-color 0.2s, box-shadow 0.4s",
        }}
      >
        {/* Holographic inner shimmer on hover */}
        {hovered && (
          <motion.div
            className="absolute inset-0 pointer-events-none"
            initial={{ opacity: 0, x: "-100%" }}
            animate={{ opacity: [0, 0.3, 0], x: ["−100%", "200%"] }}
            transition={{ duration: 0.5 }}
            style={{
              background: `linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)`,
            }}
          />
        )}
        <span className="text-[11px] relative z-10">{skill.emoji}</span>
        <span className="text-[12px] font-medium relative z-10">{skill.name}</span>
      </motion.div>
    </motion.div>
  );
}

/* ─── Corner Accent Lines ──────────────────────────────────────── */
function CornerAccent({ pos, color, visible }: { pos: string; color: string; visible: boolean }) {
  const isTop = pos.includes("top");
  const isLeft = pos.includes("left");
  return (
    <div
      className={`absolute w-5 h-5 pointer-events-none ${pos}`}
      style={{
        borderTop: isTop ? `2px solid ${color}` : undefined,
        borderBottom: !isTop ? `2px solid ${color}` : undefined,
        borderLeft: isLeft ? `2px solid ${color}` : undefined,
        borderRight: !isLeft ? `2px solid ${color}` : undefined,
        opacity: visible ? 1 : 0,
        boxShadow: visible ? `0 0 10px ${color}, 0 0 20px ${color}60` : "none",
        transition: "opacity 0.4s ease, box-shadow 0.4s ease",
      }}
    />
  );
}

/* ─── Glitch Text ──────────────────────────────────────────────── */
function GlitchText({ text, color, active }: { text: string; color: string; active: boolean }) {
  return (
    <div className="relative inline-block">
      <span className="text-white/90 font-semibold tracking-wide text-sm uppercase">{text}</span>
      {active && (
        <>
          <motion.span
            className="absolute inset-0 font-semibold tracking-wide text-sm uppercase pointer-events-none"
            style={{ color, clipPath: "inset(0 0 60% 0)", left: -2 }}
            animate={{ opacity: [0, 1, 0, 1, 0], x: [0, -3, 2, -1, 0] }}
            transition={{ duration: 0.4, repeat: Infinity, repeatDelay: 2.5 }}
          >
            {text}
          </motion.span>
          <motion.span
            className="absolute inset-0 font-semibold tracking-wide text-sm uppercase pointer-events-none"
            style={{ color: "#EC4899", clipPath: "inset(60% 0 0 0)", left: 2 }}
            animate={{ opacity: [0, 1, 0, 1, 0], x: [0, 3, -2, 1, 0] }}
            transition={{ duration: 0.4, repeat: Infinity, repeatDelay: 2.5, delay: 0.05 }}
          >
            {text}
          </motion.span>
        </>
      )}
    </div>
  );
}

/* ─── Skill Card ───────────────────────────────────────────────── */
interface RippleItem { id: number; x: number; y: number }

function SkillCard({ group, index, isInView }: {
  group: typeof groups[0]; index: number; isInView: boolean;
}) {
  const Icon = group.icon;
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [hovered, setHovered] = useState(false);
  const [shimmerPos, setShimmerPos] = useState({ x: 50, y: 50 });
  const [ripples, setRipples] = useState<RippleItem[]>([]);
  const [borderAngle, setBorderAngle] = useState(0);
  const animFrameRef = useRef<number>();

  // Rotating conic border
  useEffect(() => {
    if (hovered) {
      let angle = 0;
      const tick = () => {
        angle = (angle + 1.8) % 360;
        setBorderAngle(angle);
        animFrameRef.current = requestAnimationFrame(tick);
      };
      animFrameRef.current = requestAnimationFrame(tick);
    } else {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    }
    return () => { if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current); };
  }, [hovered]);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const rect = cardRef.current?.getBoundingClientRect();
    if (!rect) return;
    const rx = ((e.clientX - rect.left) / rect.width - 0.5) * 16;
    const ry = ((e.clientY - rect.top) / rect.height - 0.5) * -16;
    setTilt({ x: rx, y: ry });
    setShimmerPos({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    });
  }, []);

  const handleMouseLeave = useCallback(() => {
    setTilt({ x: 0, y: 0 });
    setHovered(false);
  }, []);

  const handleClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const rect = cardRef.current?.getBoundingClientRect();
    if (!rect) return;
    const id = Date.now();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setRipples((prev) => [...prev, { id, x, y }]);
    setTimeout(() => setRipples((prev) => prev.filter((r) => r.id !== id)), 900);
  }, []);

  const isWide = index === 1 || index === 2;
  const { color, colorRgb } = group;

  const borderBg = hovered
    ? `conic-gradient(from ${borderAngle}deg at 50% 50%, transparent 0%, ${color} 8%, ${color}aa 16%, transparent 25%)`
    : `rgba(255,255,255,0.07)`;

  return (
    <div className={isWide ? "md:col-span-2" : ""} style={{ perspective: "1200px" }}>
      <motion.div
        ref={cardRef}
        initial={{ opacity: 0, y: 50, scale: 0.93 }}
        animate={isInView ? { opacity: 1, y: 0, scale: 1 } : {}}
        transition={{ duration: 0.75, delay: 0.1 + index * 0.12, ease: [0.22, 1, 0.36, 1] }}
        onMouseMove={handleMouseMove}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={handleMouseLeave}
        onClick={handleClick}
        className="relative cursor-default h-full"
        style={{
          transform: `perspective(1200px) rotateX(${tilt.y}deg) rotateY(${tilt.x}deg) translateZ(${hovered ? 8 : 0}px)`,
          transition: hovered ? "transform 0.08s ease" : "transform 0.55s ease",
          borderRadius: 18,
          background: borderBg,
          padding: 1,
        }}
      >
        {/* Inner card glass surface */}
        <div
          className="relative rounded-[17px] overflow-hidden h-full"
          style={{ background: "rgba(6,6,16,0.95)" }}
        >
          {/* Corner accents */}
          <CornerAccent pos="top-0 left-0" color={color} visible={hovered} />
          <CornerAccent pos="top-0 right-0" color={color} visible={hovered} />
          <CornerAccent pos="bottom-0 left-0" color={color} visible={hovered} />
          <CornerAccent pos="bottom-0 right-0" color={color} visible={hovered} />

          {/* Dot-grid texture */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              backgroundImage: `radial-gradient(circle, rgba(${colorRgb},0.25) 1px, transparent 1px)`,
              backgroundSize: "22px 22px",
              opacity: hovered ? 0.35 : 0.12,
              transition: "opacity 0.5s ease",
            }}
          />

          {/* Ambient blob glow */}
          <div
            className="absolute -bottom-10 -right-10 w-48 h-48 rounded-full pointer-events-none"
            style={{
              background: `rgba(${colorRgb},0.2)`,
              filter: "blur(50px)",
              opacity: hovered ? 1 : 0.3,
              transition: "opacity 0.5s ease",
            }}
          />
          <div
            className="absolute -top-10 -left-10 w-36 h-36 rounded-full pointer-events-none"
            style={{
              background: `rgba(${colorRgb},0.1)`,
              filter: "blur(40px)",
              opacity: hovered ? 0.8 : 0.1,
              transition: "opacity 0.5s ease",
            }}
          />

          {/* Holographic shimmer overlay */}
          <div
            className="absolute inset-0 pointer-events-none z-20 rounded-[17px]"
            style={{
              opacity: hovered ? 0.07 : 0,
              background: `radial-gradient(ellipse at ${shimmerPos.x}% ${shimmerPos.y}%, #ffffff, #4F9CFF, #8B5CF6, #EC4899, #10B981, transparent 70%)`,
              transition: "opacity 0.3s ease",
              mixBlendMode: "screen",
            }}
          />

          {/* Sweep scan line on hover */}
          {hovered && (
            <motion.div
              key={`scan-${index}`}
              initial={{ top: "-5%" }}
              animate={{ top: "110%" }}
              transition={{ duration: 1.4, ease: "linear" }}
              className="absolute left-0 w-full pointer-events-none z-30"
              style={{
                height: 2,
                background: `linear-gradient(90deg, transparent 0%, ${color}90 30%, ${color} 50%, ${color}90 70%, transparent 100%)`,
                boxShadow: `0 0 20px ${color}80`,
              }}
            />
          )}

          {/* Ripple clicks */}
          {ripples.map((r) => (
            <motion.div
              key={r.id}
              className="absolute pointer-events-none z-40 rounded-full"
              style={{ border: `1.5px solid ${color}`, left: r.x, top: r.y }}
              initial={{ width: 0, height: 0, x: 0, y: 0, opacity: 0.8 }}
              animate={{ width: 260, height: 260, x: -130, y: -130, opacity: 0 }}
              transition={{ duration: 0.85, ease: "easeOut" }}
            />
          ))}

          {/* Card content */}
          <div className="relative z-10 p-6">
            {/* Header row */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                {/* Icon container with rotating ring */}
                <div className="relative w-11 h-11">
                  {/* Spinning outer ring */}
                  {hovered && (
                    <motion.div
                      className="absolute inset-0 rounded-xl pointer-events-none"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 2.5, repeat: Infinity, ease: "linear" }}
                      style={{
                        background: `conic-gradient(${color}, transparent, ${color})`,
                        borderRadius: 12,
                        padding: 1.5,
                      }}
                    >
                      <div className="w-full h-full rounded-[10px]" style={{ background: "rgba(6,6,16,0.95)" }} />
                    </motion.div>
                  )}
                  <div
                    className="absolute inset-0 rounded-xl flex items-center justify-center overflow-hidden"
                    style={{
                      background: `rgba(${colorRgb},0.12)`,
                      border: `1px solid rgba(${colorRgb},0.3)`,
                    }}
                  >
                    <motion.div
                      animate={hovered ? { scale: [1, 1.2, 1], rotate: [0, 10, -10, 0] } : {}}
                      transition={{ duration: 0.6, repeat: hovered ? Infinity : 0, repeatDelay: 1.5 }}
                    >
                      <Icon size={18} style={{ color }} />
                    </motion.div>
                    {/* Icon pulse halo */}
                    {hovered && (
                      <motion.div
                        className="absolute inset-0"
                        animate={{ opacity: [0, 0.5, 0] }}
                        transition={{ duration: 1.2, repeat: Infinity }}
                        style={{ background: `radial-gradient(circle, ${color}60, transparent)` }}
                      />
                    )}
                  </div>
                </div>

                <div>
                  <GlitchText text={group.label} color={color} active={hovered} />
                  <motion.p
                    className="text-[11px] mt-0.5"
                    animate={hovered ? { color: color } : { color: "rgba(113,113,122,1)" }}
                    transition={{ duration: 0.3 }}
                  >
                    {group.skills.length} skills
                  </motion.p>
                </div>
              </div>

              {/* Active badge with pulse */}
              <div className="relative">
                <div
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-full"
                  style={{ background: `rgba(${colorRgb},0.1)`, border: `1px solid rgba(${colorRgb},0.25)` }}
                >
                  <motion.div
                    className="w-1.5 h-1.5 rounded-full"
                    style={{ background: color }}
                    animate={{ opacity: [1, 0.3, 1], scale: [1, 0.6, 1] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  />
                  <Sparkles size={9} style={{ color }} />
                  <span className="text-[10px] font-medium" style={{ color }}>Active</span>
                </div>
                {/* Ping ring */}
                {hovered && (
                  <motion.div
                    className="absolute inset-0 rounded-full pointer-events-none"
                    animate={{ scale: [1, 1.5], opacity: [0.4, 0] }}
                    transition={{ duration: 1, repeat: Infinity }}
                    style={{ border: `1px solid ${color}` }}
                  />
                )}
              </div>
            </div>

            {/* Animated divider */}
            <div className="relative h-px mb-5 overflow-hidden rounded-full" style={{ background: `rgba(${colorRgb},0.1)` }}>
              <motion.div
                className="absolute inset-y-0 left-0 h-full rounded-full"
                initial={{ width: "0%" }}
                animate={isInView ? { width: "100%" } : {}}
                transition={{ duration: 1, delay: 0.3 + index * 0.15, ease: [0.22, 1, 0.36, 1] }}
                style={{ background: `linear-gradient(90deg, ${color}, ${color}40, transparent)` }}
              />
              {hovered && (
                <motion.div
                  className="absolute inset-y-0 w-16 rounded-full"
                  animate={{ left: ["-20%", "120%"] }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                  style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }}
                />
              )}
            </div>

            {/* Skill pills */}
            <div className="flex flex-wrap gap-2">
              {group.skills.map((skill, si) => (
                <MagneticPill
                  key={skill.name}
                  skill={skill}
                  color={color}
                  colorRgb={colorRgb}
                  isInView={isInView}
                  entryDelay={0.3 + index * 0.1 + si * 0.045}
                  cardHovered={hovered}
                />
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

/* ─── Main Section ─────────────────────────────────────────────── */
export function SkillsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(contentRef, { once: true });
  const [cursor, setCursor] = useState({ x: -999, y: -999 });
  const totalSkills = groups.reduce((acc, g) => acc + g.skills.length, 0);

  const handleSectionMouseMove = useCallback((e: React.MouseEvent<HTMLElement>) => {
    const rect = sectionRef.current?.getBoundingClientRect();
    if (!rect) return;
    setCursor({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  }, []);

  return (
    <section
      id="skills"
      ref={sectionRef}
      onMouseMove={handleSectionMouseMove}
      className="py-24 relative overflow-hidden"
    >
      {/* Section-wide cursor spotlight */}
      <div
        className="absolute inset-0 pointer-events-none z-0"
        style={{
          background: `radial-gradient(700px circle at ${cursor.x}px ${cursor.y}px, rgba(79,156,255,0.045), transparent 45%)`,
          transition: "background 0.05s",
        }}
      />

      {/* Ambient static glows */}
      <div className="absolute top-1/4 left-0 w-[600px] h-[600px] bg-[#4F9CFF]/4 rounded-full blur-[150px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-0 w-[500px] h-[500px] bg-[#8B5CF6]/5 rounded-full blur-[130px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-[#EC4899]/3 rounded-full blur-[100px] pointer-events-none" />

      {/* Floating neon orbs */}
      <FloatingOrb color="rgba(79,156,255,0.5)"  size={18} left="8%"  top="20%" duration={8}  delay={0}   />
      <FloatingOrb color="rgba(139,92,246,0.6)"  size={12} left="88%" top="30%" duration={11} delay={1.5} />
      <FloatingOrb color="rgba(236,72,153,0.5)"  size={14} left="15%" top="75%" duration={9}  delay={3}   />
      <FloatingOrb color="rgba(16,185,129,0.55)" size={10} left="75%" top="80%" duration={13} delay={0.8} />
      <FloatingOrb color="rgba(79,156,255,0.4)"  size={8}  left="50%" top="10%" duration={7}  delay={2}   />
      <FloatingOrb color="rgba(139,92,246,0.4)"  size={16} left="92%" top="60%" duration={10} delay={4}   />

      {/* Aurora animated lines */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            className="absolute w-full h-px opacity-20"
            style={{
              top: `${30 + i * 20}%`,
              background: `linear-gradient(90deg, transparent, ${["#4F9CFF","#8B5CF6","#EC4899"][i]}, transparent)`,
            }}
            animate={{ x: ["-100%", "100%"] }}
            transition={{ duration: 8 + i * 2, repeat: Infinity, ease: "linear", delay: i * 2 }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="max-w-5xl mx-auto px-6 relative z-10" ref={contentRef}>

        {/* Header */}
        <motion.div
          className="mb-14"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.85, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="flex items-center gap-4 mb-4">
            <motion.div
              className="h-[1px] bg-gradient-to-r from-transparent to-[#8B5CF6]"
              initial={{ width: 0 }}
              animate={isInView ? { width: 32 } : {}}
              transition={{ duration: 0.8, delay: 0.2 }}
            />
            <span className="text-[#A78BFA] uppercase tracking-[0.2em] text-[11px] font-bold">
              Skills & Expertise
            </span>
            <motion.div
              className="h-[1px] bg-gradient-to-r from-[#8B5CF6]/40 to-transparent"
              initial={{ width: 0 }}
              animate={isInView ? { width: 200 } : {}}
              transition={{ duration: 1, delay: 0.3 }}
            />
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <h2 className="text-white text-3xl md:text-5xl font-bold tracking-tight">
              My Technical{" "}
              <motion.span
                className="bg-clip-text text-transparent relative"
                style={{ backgroundImage: "linear-gradient(135deg, #4F9CFF, #8B5CF6, #EC4899)" }}
                animate={{
                  backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
                }}
                transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
              >
                Arsenal
              </motion.span>
            </h2>

            {/* Animated stat counters */}
            <div className="flex items-center gap-3">
              {[
                { label: "Categories", value: groups.length },
                { label: "Total Skills", value: totalSkills },
              ].map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.85 }}
                  animate={isInView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ duration: 0.6, delay: 0.4 + i * 0.15 }}
                  whileHover={{ scale: 1.05, y: -2 }}
                  className="text-center px-5 py-3 rounded-xl relative overflow-hidden cursor-default"
                  style={{
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.07)",
                  }}
                >
                  <div
                    className="absolute inset-0 opacity-0 hover:opacity-100 pointer-events-none transition-opacity duration-300"
                    style={{ background: "rgba(79,156,255,0.05)" }}
                  />
                  <p className="font-bold text-2xl bg-clip-text text-transparent relative z-10"
                    style={{ backgroundImage: "linear-gradient(135deg, #4F9CFF, #8B5CF6)" }}>
                    <AnimatedCounter target={stat.value} isInView={isInView} />+
                  </p>
                  <p className="text-zinc-500 text-[10px] uppercase tracking-widest relative z-10">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Bento grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <SkillCard group={groups[0]} index={0} isInView={isInView} />
          <SkillCard group={groups[1]} index={1} isInView={isInView} />
          <SkillCard group={groups[2]} index={2} isInView={isInView} />
          <SkillCard group={groups[3]} index={3} isInView={isInView} />
        </div>

        {/* Bottom tagline */}
        <motion.div
          className="flex items-center justify-center gap-3 mt-10"
          initial={{ opacity: 0, y: 10 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 0.9 }}
        >
          <div className="h-px w-12 bg-gradient-to-r from-transparent to-white/10" />
          <p className="text-zinc-600 text-xs tracking-widest uppercase">
            Hover & click to interact ·{" "}
            <motion.span
              className="bg-clip-text text-transparent"
              style={{ backgroundImage: "linear-gradient(90deg, #4F9CFF, #8B5CF6, #EC4899)" }}
              animate={{ opacity: [0.7, 1, 0.7] }}
              transition={{ duration: 2.5, repeat: Infinity }}
            >
              Always learning
            </motion.span>
          </p>
          <div className="h-px w-12 bg-gradient-to-l from-transparent to-white/10" />
        </motion.div>
      </div>
    </section>
  );
}