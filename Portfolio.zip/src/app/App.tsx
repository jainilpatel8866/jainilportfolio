import { Navbar } from "./components/Navbar";
import { ParticleBackground } from "./components/ParticleBackground";
import { HeroSection } from "./components/HeroSection";
import { AboutSection } from "./components/AboutSection";
import { SkillsSection } from "./components/SkillsSection";
import { ExperienceSection } from "./components/ExperienceSection";
import { ProjectsSection } from "./components/ProjectsSection";
import { CertificationsSection } from "./components/CertificationsSection";
import { ContactSection } from "./components/ContactSection";
import { Footer } from "./components/Footer";
import { ScrollProgress } from "./components/ScrollProgress";
import { CursorGlow } from "./components/CursorGlow";

export default function App() {
  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#E8E8ED] overflow-x-hidden relative">
      <CursorGlow />
      <ScrollProgress />
      <ParticleBackground />
      <Navbar />
      <HeroSection />
      <div className="relative z-10">
        <AboutSection />
        <SkillsSection />
        <ExperienceSection />
        <ProjectsSection />
        <CertificationsSection />
        <ContactSection />
        <Footer />
      </div>

      <style>{`
        @keyframes gradientShift {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        @keyframes shimmer {
          0% { transform: translateX(-100%) skewX(-20deg); }
          100% { transform: translateX(200%) skewX(-20deg); }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
        @keyframes pulse-glow {
          0%, 100% { box-shadow: 0 0 5px rgba(79,156,255,0.3); }
          50% { box-shadow: 0 0 20px rgba(79,156,255,0.6), 0 0 40px rgba(139,92,246,0.3); }
        }
        html, body {
          scroll-behavior: smooth;
          position: relative;
          min-height: 100%;
        }
        * {
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }
        ::-webkit-scrollbar {
          width: 5px;
        }
        ::-webkit-scrollbar-track {
          background: #0A0A0A;
        }
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(to bottom, #4F9CFF, #8B5CF6);
          border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(to bottom, #60A5FA, #A78BFA);
        }
        ::selection {
          background: rgba(79, 156, 255, 0.3);
          color: white;
        }
        /* Smooth transitions for all interactive elements */
        a, button {
          transition-timing-function: cubic-bezier(0.22, 1, 0.36, 1);
        }
      `}</style>
    </div>
  );
}